## cobra 관련모듈 설치
# cobra 설치 (library)
go get -u github.com/spf13/cobra@latest


# cobra-cli 설치 ( 이전에는 cobra 현재는 cobra-cli)
go install github.com/spf13/cobra-cli@latest

##---


## 프로젝트 구성
# 빈 디렉토리 생성 및 이동
mkdir testcli && cd testcli

# go 디렉토리 초기화 (go.mod 생성됨)
go mod init testcli

# go 프로젝트에 cobra 초기화 (cmd/root.go 생성됨)
cobra-cli init 

# 필요한 명령어 추가 ( cmd/serve.go 생성됨)
cobra-cli add serve

# serve.go에 필요한 기능 추가.

## 현재 기능 테스트
go run main.go serve 


## 프로젝트 빌드 및 명령어 수행
go build
testcli serve
