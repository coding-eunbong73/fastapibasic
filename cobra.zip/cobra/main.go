/*
Copyright © 2022 NAME HERE <EMAIL ADDRESS>

*/
package main

import "testcli/cmd"

func main() {
	cmd.Execute()
}
